module.exports = class Produto{

    constructor(codigo, nome, area, dataInicio, dataTermino, 
        preRequisito){
            
        if(codigo)
            this.codigo = codigo 
            this.nome = nome 
            this.area = area 
            this.dataInicio = dataInicio
            this.dataTermino = dataTermino
            this.preRequisito = preRequisito
    }

    getCodigo(){
        return this.codigo;
    }

    setCodigo(codigo){
         this.codigo = codigo;
    }

    getNome(){
        return this.nome;
    }

    setNome(nome){
        this.nome = nome;
    }
    
    getArea(){
        return this.area;
    }

    setArea(area){
        this.area = area;
    }

    getDataInicio(){
        return this.dataInicio;
    }

    setDataInicio(dataInicio){
        this.dataInicio = dataInicio;
    }

    getDataTermino(){
        return this.dataTermino;
    }

    setDataTermino(dataTermino){
         this.dataTermino = dataTermino;
    }

    getPreRequisito(){
        return this.preRequisito;
    }

    setPreRequisito(preRequisito){
         this.preRequisito = preRequisito;
    }    
}