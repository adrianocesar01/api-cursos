const jwt = require('jsonwebtoken')

function tokenValidation(request, response, next){

    try{
    
    var tokenEnviado = request.headers.authorization 
    tokenEnviado = tokenEnviado.split(' ')[1]

    if(!tokenEnviado){response.status(401).json({mensagem: 'token não informado'})}
    
    jwt.verify(tokenEnviado, '0e91fb0481f0bd481efdebc88dd6f6e3') 
                             // oGaloGanhô // Md5 Hash generator
       
    }
    catch(error){response.status(401).json({mensagem: 'token inválido!'})}

    return next()

}

module.exports = tokenValidation