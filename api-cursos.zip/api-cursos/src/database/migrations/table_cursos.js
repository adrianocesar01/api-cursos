const knex = require('knex')

exports.up = async (knex) => { 

    return knex.schema.createTable('cursos', (table) => {

        table.uuid('codigo').primary()
        
        table.string('nome', 30).unique().notNullable()

        table.string('area', 30).notNullable()

        table.string('dataInicio', 30).notNullable()

        table.string('dataTermino', 30).notNullable()

        table.string('preRequisito', 30).notNullable()

    } )      
}

exports.down = async (knex) => {

    return knex.schema.dropTable('cursos')
}