const express = require('express')  
const app = express()

const routers = require('./routers/main.router')

const {errors} = require('celebrate')

app.use(express.json())
app.use(routers)
app.use(errors())

app.listen(3000, () => { 
    console.log("api-cursos em execução na porta 3000...") 
})