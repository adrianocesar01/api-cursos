const express =  require('express')
const routers = express.Router()

const cursosRouter = require('./cursos.router')
const usersRouter = require('./users.router')
const sessionsRouter = require('./sessions.router')

routers.use('/cursos', cursosRouter)
routers.use('/users', usersRouter)
routers.use('/sessions', sessionsRouter)

module.exports = routers