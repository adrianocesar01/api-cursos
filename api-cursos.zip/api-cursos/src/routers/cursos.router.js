const  express = require('express')

const routers = express.Router()

const {uuid} = require('uuidv4')

const {celebrate, Joi} = require('celebrate')

const  database = require('../database/connection')

const tokenValidation = require('../middleware/tokenValidation')
routers.use(tokenValidation)


const Curso = require('../model/curso.js')

routers.post('/',  celebrate({ 

    body : Joi.object().keys({ 
        nome : Joi.string().min(3).max(30).required(), 
        area : Joi.string().max(30).required(), 
        dataInicio : Joi.string().min(8).max(10).required(), 
        dataTermino :Joi.string().min(8).max(10).required(), 
        preRequisito :Joi.string().max(30).required(), 
    })
    
    }) , async function(request, response){

    try{
        const curso = new Curso(uuid(), 
        request.body.nome, 
        request.body.area, 
        request.body.dataInicio, 
        request.body.dataTermino, 
        request.body.preRequisito)
     
        await database('cursos').insert(curso)
        response.status(201).json(curso)
    }

    catch(error){
        response.status(400).json({Error: `${error}`})
    }
})

routers.get('/', async function (request, response) {

    try{

        const cursos = await database('cursos').select('*')
        response.status(200).json(cursos)
        }
        catch(error){response.status(400).json({Error: `${error}`})}
    
    })

routers.get('/:codigo', async function (request, response) {

   try{
   
    const {codigo} = request.params    
    const curso = await database('cursos').where('codigo', codigo).first()

    if(!curso) {
        return response.status(400).json(
            {error: 'Codigo ' + codigo + ' não encontrado' })
    }

    response.status(200).json(curso)}

    catch(error){
        response.status(400).json({Error: `${error}`})}

})

routers.delete('/:codigo', async function (request, response) {

    try{
    const {codigo} = request.params    
    const curso = await database('cursos').where('codigo', codigo).first()

    if(!curso) {
        return response.status(400).json(
            {error: 'Codigo ' + codigo + ' não encontrado' })
    }

    await database('cursos').where('codigo', codigo).delete()

    response.status(204).json() 
    }
    catch(error){
        response.status(400).json({Error: `${error}`})
        }

})

routers.put('/:codigo' ,  celebrate({ 

    body : Joi.object().keys({ 
        nome : Joi.string().min(3).max(30).required(), 
        area : Joi.string().max(30).required(), 
        dataInicio : Joi.string().min(8).max(10).required(), 
        dataTermino :Joi.string().min(8).max(10).required(), 
        preRequisito :Joi.string().max(30).required(), 

        })
    
        }) , async function (request, response) {

      try{    

        const {codigo} = request.params    
        const curso = await database('cursos').where('codigo', codigo).first()

        if(!curso) {
            return response.status(400).json(
                {error: 'Codigo ' + codigo + ' não encontrado' })
        }

       const cursoAlterado = new Curso(

        request.body.codigo, 
        request.body.nome, 
        request.body.area, 
        request.body.dataInicio,  
        request.body.dataTermino, 
        request.body.preRequisito, true)
     
    await database('cursos').update(cursoAlterado).where('codigo', codigo)

    response.status(200).json({codigo, ... cursoAlterado })   
    }

    catch(error){
    response.status(400).json({Error: `${error}`})
    }

})

module.exports = routers